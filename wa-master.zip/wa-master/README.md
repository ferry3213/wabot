## Bot Menu
┌──• *Group Menu*\
│\
│.linkgroup\
│.ephemeral [option]\
│.setppgc [image]\
│.setname [text]\
│.setdesc [text]\
│.editinfo [option]\
│.kick @user\
│.hidetag [text]\
│.everyone [text]\
│.totag [reply]\
│.antilink [on/off]\
│.mute [on/off]\
│.vote [text]\
│.devote\
│.upvote\
│.cekvote\
│.hapusvote\
│\
└───────•\
\
┌──• *Youtube  Menu*\
│\
│.ytmp3 [url]\
│.ytmp4 [url]\
│.play [query]\
│\
└───────•\
\
┌──• *Convert Menu*\
│\
│.attp [text]\
│.ttp [text]\
│.toimage\
│.togif\
│.tomp4\
│.tomp3\
│.tovn\
│.sticker\
│.stickerwm\
│.emojimix\
│\
└───────•\
\
┌──• *Main Menu*\
│\
│.ping\
│.owner\
│.menu / help / ?\
│.quoted\
│.listonline\
│\
└───────•\
\
┌──• *Islamic Menu*\
│\
│.iqra\
│.alquran\
│.tafsirsurah\
│\
└───────•\
\
┌──• *Voice Changer*\
│\
│.bass\
│.blown\
│.deep\
│.earrape\
│.fast\
│.fat\
│.nightcore\
│.reverse\
│.robot\
│.slow\
│.tupai\
│\
└───────•
